/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

/**
 *
 * @author priscyla.poliveira
 */
public class ItemVenda {

    public ItemVenda(String descricaoProduto, int qtd, double valorUnitario) {
        this.descricaoProduto = descricaoProduto;
        this.qtd = qtd;
        this.valorUnitario = valorUnitario;
    }
    public ItemVenda(){
        
    }

    private String descricaoProduto;
    private int qtd;
    private double valorUnitario;

    public String getDescricaoProduto() {
        return descricaoProduto;
    }

    public void setDescricaoProduto(String descricaoProduto) {
        this.descricaoProduto = descricaoProduto;
    }

    public int getQtd() {
        return qtd;
    }

    public void setQtd(int qtd) {
        this.qtd = qtd;
    }

    public double getValorUnitario() {
        return valorUnitario;
    }

    public void setValorUnitario(double valorUnitario) {
        this.valorUnitario = valorUnitario;
    }

}
