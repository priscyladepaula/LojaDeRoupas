/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package util;

import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.border.LineBorder;

/**
 *
 * @author sunse
 */
public class Validador {
    //método para validar campos vazios na tela
    //saber onde colocar os avisos sem precisar do for para não gerar vários avisos
    public static void CamposVazios(JTextField[] txt, JLabel[] lbl){
        
        boolean possuiCamposVazios = false;
        
        for(int i = 0; i < txt.length; i++){
            if(txt[i].getText().isEmpty()){
                txt[i].setBorder(new LineBorder(Color.RED));
                lbl[i].setForeground(Color.RED);
                possuiCamposVazios = true; 
            }
            else if(txt[i].getText().length() > 0){
                txt[i].setBorder(new LineBorder(new Color(109,109,109)));
                lbl[i].setForeground(Color.BLACK);
            }
        }
        
        if(possuiCamposVazios){
            JOptionPane.showMessageDialog(null,"Preencha os campos em vermelho!");
        }
    }
    
    public static boolean ValidarNumero(JTextField[] txt, JLabel[] lbl) {
        try {
            
            /*for(int i = 0; i < txt.length; i++){
                txt[i].setBorder(new LineBorder(new Color(109,109,109)));
                lbl[i].setForeground(Color.BLACK);
            }*/
            
            for(int i = 0; i < txt.length; i++){
                int valorConvertido = Integer.parseInt(txt[i].getText());
                txt[i].setBorder(new LineBorder(new Color(109,109,109)));
                lbl[i].setForeground(Color.BLACK);
            }
            return true;
            
        } catch (NumberFormatException e) {
            for(int i = 0; i < txt.length; i++){
                txt[i].setBorder(new LineBorder(Color.RED));
                lbl[i].setForeground(Color.RED);
            }
            
            //JOptionPane.showMessageDialog(null,"Digite somente inteiros!");
            return false;
            
        } catch (IllegalArgumentException e) {
            for(int i = 0; i < txt.length; i++){
                txt[i].setBorder(new LineBorder(Color.RED));
                lbl[i].setForeground(Color.RED);
            }
            return false;
        }
    }
}
