/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import DAO.ClienteDAO;
import java.util.ArrayList;
import model.Cliente;

/**
 *
 * @author sunse
 */
public class ClienteController {
    
    public static boolean Salvar(String nome, String cpf, String genero, String dataNasc, String estadoCivil,
                                 String tipoEndereco, String endereco, int numero, int cep, String bairro, String complemento, String cidade,
                                 String uf, String email, long telefone){
        
        Cliente c = new Cliente(nome, cpf, genero, dataNasc, estadoCivil,
                                tipoEndereco, endereco, numero, cep, bairro, complemento, cidade,
                                uf, email, telefone);
        
        return ClienteDAO.SalvarCliente(c);
    }
    
    public static boolean Excluir(int idcliente){
        return ClienteDAO.ExcluirCliente(idcliente);
    }
    
    public static boolean Atualizar(String nome, String cpf, String genero, String dataNasc, String estadoCivil,
                                    String tipoEndereco, String endereco, int numero, int cep, String bairro, String complemento, String cidade,
                                    String uf, String email, long telefone, int id){
        
        
        Cliente c = new Cliente(nome, cpf, genero, dataNasc, estadoCivil,
                                tipoEndereco, endereco, numero, cep, bairro, complemento, cidade,
                                uf, email, telefone, id);
        
        return ClienteDAO.AtualizarCliente(c);
    }
    
    public static boolean Pesquisar(int cpf){
        return true;
    }
    
    public static ArrayList<String[]> getClientes(){
        
        ArrayList<Cliente> clientes = ClienteDAO.getClientes();
        ArrayList<String[]> listaClientes = new ArrayList<>();
        
        for(int i = 0; i < clientes.size(); i++){
            listaClientes.add(new String[]{String.valueOf(clientes.get(i).getId()), clientes.get(i).getNome(), 
                              clientes.get(i).getCpf(), clientes.get(i).getGenero(),
                              String.valueOf(clientes.get(i).getDataNasc()), clientes.get(i).getEstadoCivil(),
                              clientes.get(i).getTipoEndereco(), clientes.get(i).getEndereco(),
                              String.valueOf(clientes.get(i).getNumeroResidencia()), String.valueOf(clientes.get(i).getCep()),
                              clientes.get(i).getBairro(), clientes.get(i).getCidade(), clientes.get(i).getUF(),
                              clientes.get(i).getEmail(), String.valueOf(clientes.get(i).getTelefone())});
        }
        
        return listaClientes;
    }
    
    public static Cliente getClienteByCPF(String cpf){
        return ClienteDAO.getClienteByCPF(cpf);
    }
    
     public static Cliente getClienteByID(int id){
        return ClienteDAO.getClienteById(id);
     }
     
     public static String getCpfByName(String nome){
        return ClienteDAO.getCpfByName(nome);
     }
}
