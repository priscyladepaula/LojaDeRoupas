/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import java.util.ArrayList;
import DAO.VendaDAO;
import model.ItemVenda;
import model.Venda;

/**
 *
 * @author priscyla.poliveira
 */
public class VendaController {
    public static boolean SalvarVenda(Venda venda){
        return DAO.VendaDAO.SalvarVenda(venda);
    }
        
    public static int RecuperaIdVenda(String cpf, String DataVenda, Double valorTotalPago){
        return VendaDAO.recuperaIdDaVenda(cpf, DataVenda, valorTotalPago);
    }
    
    public static boolean SalvarItensVenda(ItemVenda item, int idVenda){
        return VendaDAO.SalvarItensVenda(item, idVenda);
    }
    
    public static ArrayList<Venda> getVendas(){
        return DAO.VendaDAO.getVendas();
    }
    
    public static ArrayList<ItemVenda> getItensVenda(int idVenda){
        return VendaDAO.getItensVenda(idVenda);
    }
}
