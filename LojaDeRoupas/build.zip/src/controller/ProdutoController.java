/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import DAO.ProdutoDAO;
import java.util.ArrayList;
import model.Produto;

/**
 *
 * @author sunse
 */
public class ProdutoController {
    
    public static boolean Salvar(String descricao, String tamanho, String cor, String genero, int qtd, double valorUnitario){
        Produto p = new Produto(descricao, tamanho, cor, genero, qtd, valorUnitario);
        return ProdutoDAO.SalvarProduto(p);
    }
    
    public static boolean Excluir(int id){
        return ProdutoDAO.ExcluirProduto(id);
    }
    
    public static boolean Atualizar(String descricao, String tamanho, String cor, String genero, int qtd, double valorUnitario, int codigo){
        Produto p = new Produto(descricao, tamanho, cor, genero, qtd, valorUnitario, codigo);
        return ProdutoDAO.AtualizarProduto(p); 
    }
    
    public static ArrayList<Produto> Pesquisar(String valor){
        return ProdutoDAO.PesquisarProduto(valor);
    }
    
    public static ArrayList<String[]> getProdutos(){
        ArrayList<Produto> produtos = ProdutoDAO.getProdutos();
        ArrayList<String[]> listaProdutos = new ArrayList<>();
        
        for(int i=0; i < produtos.size(); i++){
            listaProdutos.add(new String[]{String.valueOf(produtos.get(i).getCodigo()),produtos.get(i).getDescricao(), produtos.get(i).getTamanho(),
                                           produtos.get(i).getCor(), produtos.get(i).getGenero(),
                                           String.valueOf(produtos.get(i).getQtd()), String.valueOf(produtos.get(i).getValorUnitario())});
        }
        
        return listaProdutos;
    }

}
